# Zentwik Next UI 原型交接包

## 一、各页面权威原型对照（务必以最新演进版为准，勿用早期草稿）
1. **全局主壳层 / 首页总览 / 方案库 / 能力与诊断 / 系统设置**：
   - `zentwik-final-round7.html`（核心一屏双栏首页：4 格遥测条 + 左侧功能域与扩展槽位 + 右侧近期动态时间线）
   - `zentwik-home-refined.html`（基于 round7 精修壳层：顶栏左上角仅保留唯一状态圆点、左栏 Zentwik 六边形矢量 Logo + 8 项 SVG 导航、6px 细长自绘滚动条）
2. **CPU 调校**：
   - `zentwik-cpu-exclusive-24c.html`（最新演进版：互斥模式 + 24 核拓扑扩展）
   - `zentwik-cpu-refined.html`（基于 exclusive-24c 去除所有原生 `<select>` / `<input type="range">` / 原生滚动条，接入统一暗色主壳层）
3. **进程与调度**：
   - `zentwik-scheduling-neo.html`（最终版：无边框进程流 + 悬浮 Batch Island + 右侧 Dock 规则/掩码库 + 16/32T 核心掩码画布）
4. **电源管理 & 场景自动化**：
   - `zentwik-power-scenarios-round6.html`（最终版：系统电源计划参数树 + 场景触发器与按域独立仲裁）

> 注：其余历史文件（`shell-prototype`、`home-round3`、`co-*`、`cpu-tuning-round4`、`cpu-capability-driven`、`scheduling-round5/polished/avantgarde`）仅供追溯演进过程，**禁止直接作为最终实现蓝本**。

## 二、铁律与避坑注意事项
1. **零原生控件**：WPF 中必须无 `x:Key` 全局隐式覆写 `ScrollBar`、`ScrollViewer`、`ComboBox`、`CheckBox`、`TextBox`、`Slider`、`Button`、`ToolTip`、`ContextMenu`，绝不允许露出 Windows 原生滚动条或原生下拉框。
2. **顶栏与左栏极简克制**：
   - 顶栏左上角只保留唯一状态绿点，禁止堆砌 `CPU 型号 / Worker 已连接` 等冗余文字；
   - 左栏顶部必须有 Zentwik 精密矢量 Logo + 折叠按钮，下方严格对应 8 个独立页面（24×24 线性 SVG `Path` 图标），禁止在左栏再放重复绿点或状态文本。
3. **首页一屏布局**：保留 4 格遥测条 + 左右双栏（功能域与扩展槽位 | 近期动态时间线），禁止强行塞入大曲线框或重复的“生效态表格”把时间线挤到首屏下方。
4. **自定义强调色**：`系统设置 -> 外观与语言` 中的强调色必须支持任意自定义 Hex 色值输入与动态重算衍生色，不能写死几个固定色板。
5. **仓库与测试约束**：
   - 仅提交到 `feat/ui-redesign` 分支，不要修改 `next`；
   - 保持 `MainTabs` 中 `Plans` 索引为 1，`AutomationProperties.Name` 覆盖所有交互控件（跳过 `ComboBox` 内部 `DropToggle`），保持 `zh-CN`/`zh-TW`/`en-US` 三语 Key 与占位符一致。
